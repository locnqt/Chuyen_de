﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BANHANG.Models.Reponses
{
    public class MassengeReponse
    {
        public string Mass { get; set; }
        public bool flag { get; set; }
    }
}
