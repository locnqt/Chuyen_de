﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BANHANG.Models.Reponses
{
    public class PaymentReponse
    {
        public string Sothe { get; set; }
        public bool flag { get; set; }
    }
}
