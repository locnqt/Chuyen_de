﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BANHANG.Models.Requests
{
    public class PaymentRequest
    {
        public string SoThe { get; set; }
        public string MaOTP { get; set; }
    }
}
